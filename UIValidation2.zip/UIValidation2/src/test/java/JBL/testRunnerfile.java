package JBL;

public class testRunnerfile {
	
	public static void main(String[]args) throws InterruptedException
	{
		JBLTest jbl=new JBLTest();
		
		JBLTest.setupMyBrowser();
		JBLTest.ValidatePageTitle();
		JBLTest.Search();
		JBLTest.ImageValidation();
		JBLTest.validateScroll();
		JBLTest.ValidateLink();
		JBLTest.driverQuit();
	}

}
