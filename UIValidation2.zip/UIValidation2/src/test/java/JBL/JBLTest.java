package JBL;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotEquals;
import static org.testng.Assert.assertTrue;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class JBLTest {

	static WebDriver driver;
	private static By Home_img = By.xpath("//*[@class=\\\"reimagine__hero__image stagger-init\\\"]");
	private static By Link = By.xpath("//*[@class='navigation']/div//a");
	private static By searchIcon = By.xpath("//i[@class='desktop-search__icon']");
	private static By searchinputText = By.xpath("//*[@class=\"desktop-search__input js-nav-search\"]");

	public static void setupMyBrowser() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.get("https://www.jaguarlandrover.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	public static void ValidatePageTitle() {
		String title = driver.getTitle();
		System.out.println(title);

		String CurrentURL = driver.getCurrentUrl();
		System.out.println(CurrentURL);
		assertEquals(title, "JLR Corporate Website");
		assertEquals(CurrentURL, "https://www.jaguarlandrover.com/");
		// verify image
		WebElement i = driver.findElement(Home_img);
		// Javascript executor to check image
		Boolean p = (Boolean) ((JavascriptExecutor) driver).executeScript("return arguments[0].complete "
				+ "&& typeof arguments[0].naturalWidth != \"undefined\" " + "&& arguments[0].naturalWidth > 0", i);

		// verify if status is true
		if (p) {
			System.out.println("Logo present");
		} else {
			System.out.println("Logo not present");
		}
	}
	public static void ValidateLink() throws InterruptedException
	{
		String[] links = null;
		int linksCount = 0;
		List<WebElement> linksize = driver.findElements(By.tagName("a")); 
		linksCount = linksize.size();
		System.out.println("Total no of links Available: "+linksCount);
		links= new String[linksCount];
		System.out.println("List of links Available: ");  
		// print all the links from webpage 
		for(int i=0;i<linksCount;i++)
		{
		links[i] = linksize.get(i).getAttribute("href");
		System.out.println(linksize.get(i).getAttribute("href"));
		} 
		// navigate to each Link on the webpage
		for(int i=0;i<linksCount;i++)
		{
		driver.navigate().to(links[i]);
		Thread.sleep(3000);
		}
	}

	public static void Search() throws InterruptedException {
		WebElement search = driver.findElement(searchIcon);
		WebElement searchinputText1 = driver.findElement(searchinputText);
		search.click();
		searchinputText1.sendKeys("CSR");
		Thread.sleep(2000);
		searchinputText1.sendKeys(Keys.TAB, Keys.ENTER);

	}

	public static void ImageValidation() throws InterruptedException {
		WebElement img = driver.findElement(By.xpath("//img[@class=\"corp-header__logo-img\"]"));
		assertTrue(img.isDisplayed());

	}

	public static void validateScroll() {
		WebElement link = driver.findElement(By.xpath("//a[@href='https://www.tatamotors.com/']"));
		String execScript = "return document.documentElement.scrollHeight>document.documentElement.clientHeight;";
		JavascriptExecutor scrollBarPresent = (JavascriptExecutor) driver;
		Boolean test = (Boolean) (scrollBarPresent.executeScript(execScript));
		if (test == true) {
			System.out.print("Scrollbar is present.");
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", link);
		} else if (test == false) {
			System.out.print("Scrollbar is not present.");
		}
	}

	public static void driverQuit() {
		driver.quit();
	}

}
